WoronXiuwVip — APK derleme notları

Bu arşiv Android Studio kaynak projesidir; APK dosyası değildir.

APK oluşturma:
1. Bilgisayara Android Studio kur: https://developer.android.com/studio
2. Android Studio > Open ile bu klasörü aç.
3. Gradle Sync tamamlanana kadar bekle. Gerekirse Android SDK Platform 34 ve JDK 17 kur.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. Derleme başarılı olursa APK genellikle app/build/outputs/apk/debug/app-debug.apk yolunda olur.

Notlar:
- Bu çalışma ortamında Android SDK/Gradle derleme araçları bulunmadığı için burada APK derlenip doğrulanamadı.
- Projedeki AntiBan sınıfı bir iskelettir; gerçek bir ban önleme veya güvenlik garantisi sağlamaz.
- APK'yı yalnızca güvendiğin kaynaklardan yükle ve istediği izinleri dikkatle kontrol et.

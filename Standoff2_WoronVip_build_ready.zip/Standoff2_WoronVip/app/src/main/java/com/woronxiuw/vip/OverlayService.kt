package com.woronxiuw.vip

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.woronxiuw.vip.cheat.AntiBan
import com.woronxiuw.vip.cheat.AutoChat

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var menuView: View? = null
    private var isVip = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isVip = intent?.getBooleanExtra("vip", false) ?: false
        startForeground(1, createNotification())
        showMenu()
        AntiBan.applyLayer(2)
        if (isVip) AutoChat.start(this)
        return START_STICKY
    }

    private fun createNotification(): Notification {
        val channelId = "wx_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "WoronXiuwVip", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("WoronXiuwVip")
            .setContentText("Menü aktif")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
    }

    private fun showMenu() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        menuView = inflater.inflate(R.layout.overlay_menu, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50
        params.y = 200

        menuView?.findViewById<Button>(R.id.btnClose)?.setOnClickListener {
            stopSelf()
        }

        menuView?.findViewById<Button>(R.id.btnStart)?.setOnClickListener {
            // Standoff 2 aç
            val launch = packageManager.getLaunchIntentForPackage("com.axlebolt.standoff2")
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
        }

        // sürükle
        menuView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(menuView, params)
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(menuView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        menuView?.let { windowManager.removeView(it) }
        AutoChat.stop()
    }
}

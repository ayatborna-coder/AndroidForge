package com.woronxiuw.vip

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etKey = findViewById<EditText>(R.id.etKey)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val key = etKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Key gir", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (KeyManager.isAdmin(key)) {
                startActivity(Intent(this, AdminPanelActivity::class.java))
                return@setOnClickListener
            }

            val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
            val (ok, type) = KeyManager.validate(this, key, deviceId)

            if (!ok) {
                Toast.makeText(this, "Key geçersiz: $type", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "Üstte gösterme izni ver, sonra tekrar bas", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val svc = Intent(this, OverlayService::class.java)
            svc.putExtra("vip", type == "VIP")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc)
            } else {
                startService(svc)
            }
            Toast.makeText(this, "Menü açıldı ($type)", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}

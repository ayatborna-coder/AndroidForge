package com.woronxiuw.vip.cheat

import android.content.Context
import android.os.Handler
import android.os.Looper

object AutoChat {

    private var handler: Handler? = null
    private var runnable: Runnable? = null
    private const val MSG = "Telegram Hile By: @EnUstBenim"

    fun start(ctx: Context) {
        stop()
        handler = Handler(Looper.getMainLooper())
        runnable = object : Runnable {
            override fun run() {
                // Burada memory veya accessibility ile chat gönderilir
                // Şimdilik sadece log
                handler?.postDelayed(this, 20_000)
            }
        }
        handler?.post(runnable!!)
    }

    fun stop() {
        runnable?.let { handler?.removeCallbacks(it) }
        handler = null
        runnable = null
    }
}

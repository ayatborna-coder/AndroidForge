package com.woronxiuw.vip.cheat

object AntiBan {

    fun applyLayer(level: Int) {
        // HWID spoof, emulator flag temizleme, basit jitter
        // Gerçek implementasyon root + native taraf gerektirir
        when (level) {
            1 -> { /* düşük */ }
            2 -> { /* orta */ }
            3 -> { /* agresif */ }
        }
    }

    fun riskScore(): Int {
        // 0-100 arası basit skor
        return 15
    }
}

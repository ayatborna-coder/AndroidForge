package com.woronxiuw.vip

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object KeyManager {

    private const val ADMIN_KEY = "Woronxiuw0909"
    private const val PREFS = "wx_keys"

    data class KeyInfo(
        val key: String,
        val isVip: Boolean,
        val maxUsers: Int,
        val days: Int,
        val created: Long,
        val usedDevices: MutableSet<String> = mutableSetOf(),
        val isManager: Boolean = false,
        val permissions: MutableSet<String> = mutableSetOf(),
        var banned: Boolean = false
    )

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isAdmin(input: String): Boolean = input.trim() == ADMIN_KEY

    fun createKey(
        ctx: Context,
        isVip: Boolean,
        maxUsers: Int,
        days: Int,
        isManager: Boolean = false,
        permissions: Set<String> = emptySet()
    ): String {
        val key = "WX-" + UUID.randomUUID().toString().take(8).uppercase()
        val info = KeyInfo(
            key = key,
            isVip = isVip,
            maxUsers = maxUsers,
            days = days,
            created = System.currentTimeMillis(),
            isManager = isManager,
            permissions = permissions.toMutableSet()
        )
        saveKey(ctx, info)
        return key
    }

    fun validate(ctx: Context, key: String, deviceId: String): Pair<Boolean, String> {
        if (isAdmin(key)) return true to "ADMIN"
        val info = loadKey(ctx, key) ?: return false to "INVALID"
        if (info.banned) return false to "BANNED"
        val expire = info.created + info.days * 24L * 60 * 60 * 1000
        if (System.currentTimeMillis() > expire) return false to "EXPIRED"
        if (info.usedDevices.size >= info.maxUsers && deviceId !in info.usedDevices) {
            return false to "MAX_USERS"
        }
        info.usedDevices.add(deviceId)
        saveKey(ctx, info)
        return true to if (info.isVip) "VIP" else "NORMAL"
    }

    fun getAllKeys(ctx: Context): List<KeyInfo> {
        val raw = prefs(ctx).getString("keys", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<KeyInfo>()
        for (i in 0 until arr.length()) {
            list.add(fromJson(arr.getJSONObject(i)))
        }
        return list
    }

    fun banKey(ctx: Context, key: String) {
        val info = loadKey(ctx, key) ?: return
        info.banned = true
        saveKey(ctx, info)
    }

    private fun saveKey(ctx: Context, info: KeyInfo) {
        val all = getAllKeys(ctx).toMutableList()
        val idx = all.indexOfFirst { it.key == info.key }
        if (idx >= 0) all[idx] = info else all.add(info)
        val arr = JSONArray()
        all.forEach { arr.put(toJson(it)) }
        prefs(ctx).edit().putString("keys", arr.toString()).apply()
    }

    private fun loadKey(ctx: Context, key: String): KeyInfo? =
        getAllKeys(ctx).find { it.key == key }

    private fun toJson(info: KeyInfo): JSONObject {
        return JSONObject().apply {
            put("key", info.key)
            put("isVip", info.isVip)
            put("maxUsers", info.maxUsers)
            put("days", info.days)
            put("created", info.created)
            put("usedDevices", JSONArray(info.usedDevices.toList()))
            put("isManager", info.isManager)
            put("permissions", JSONArray(info.permissions.toList()))
            put("banned", info.banned)
        }
    }

    private fun fromJson(obj: JSONObject): KeyInfo {
        val devices = mutableSetOf<String>()
        val devArr = obj.optJSONArray("usedDevices") ?: JSONArray()
        for (i in 0 until devArr.length()) devices.add(devArr.getString(i))
        val perms = mutableSetOf<String>()
        val permArr = obj.optJSONArray("permissions") ?: JSONArray()
        for (i in 0 until permArr.length()) perms.add(permArr.getString(i))
        return KeyInfo(
            key = obj.getString("key"),
            isVip = obj.getBoolean("isVip"),
            maxUsers = obj.getInt("maxUsers"),
            days = obj.getInt("days"),
            created = obj.getLong("created"),
            usedDevices = devices,
            isManager = obj.optBoolean("isManager", false),
            permissions = perms,
            banned = obj.optBoolean("banned", false)
        )
    }
}

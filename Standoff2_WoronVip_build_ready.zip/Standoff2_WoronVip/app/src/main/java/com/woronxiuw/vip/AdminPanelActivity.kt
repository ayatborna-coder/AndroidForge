package com.woronxiuw.vip

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminPanelActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        val etDays = findViewById<EditText>(R.id.etDays)
        val etMaxUsers = findViewById<EditText>(R.id.etMaxUsers)
        val swVip = findViewById<Switch>(R.id.swVip)
        val swManager = findViewById<Switch>(R.id.swManager)
        val btnCreate = findViewById<Button>(R.id.btnCreate)
        val tvKeys = findViewById<TextView>(R.id.tvKeys)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        fun refresh() {
            val keys = KeyManager.getAllKeys(this)
            val sb = StringBuilder()
            keys.forEach {
                sb.append("${it.key} | VIP:${it.isVip} | Max:${it.maxUsers} | Days:${it.days} | Used:${it.usedDevices.size} | Ban:${it.banned}\n")
            }
            tvKeys.text = sb.toString().ifEmpty { "Henüz key yok" }
            tvStatus.text = "Toplam key: ${keys.size}\nAktif: ${keys.count { !it.banned }}"
        }

        refresh()

        btnCreate.setOnClickListener {
            val days = etDays.text.toString().toIntOrNull() ?: 30
            val max = etMaxUsers.text.toString().toIntOrNull() ?: 1
            val key = KeyManager.createKey(
                this,
                isVip = swVip.isChecked,
                maxUsers = max,
                days = days,
                isManager = swManager.isChecked
            )
            Toast.makeText(this, "Key oluşturuldu: $key", Toast.LENGTH_LONG).show()
            refresh()
        }
    }
}
